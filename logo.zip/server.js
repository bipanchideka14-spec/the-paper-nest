const dns = require("dns");
dns.setServers(["8.8.8.8", "1.1.1.1"]);

const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config();

const app = express();

// Routes
const taskRoutes = require("./routes/tasks");
const authRoutes = require("./routes/auth");

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend files
app.use(express.static(path.join(__dirname)));

// API routes
app.use("/api/tasks", taskRoutes);
app.use("/api/auth", authRoutes);

// Test route
app.get("/api/test", (req, res) => {
  res.json({
    message: "Daily Planner backend is working!"
  });
});

// Elastic Beanstalk provides the PORT
const PORT = process.env.PORT || 8080;

// MongoDB connection
console.log(
  "MONGODB_URI starts with:",
  process.env.MONGODB_URI?.substring(0, 20)
);

mongoose
  .connect(process.env.MONGODB_URI)
  .then(() => {
    console.log("MongoDB connected successfully");

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on port ${PORT}`);
    });
  })
  .catch((error) => {
    console.error("MongoDB connection failed:", error);
  });