const express = require("express");
const jwt = require("jsonwebtoken");

const Task = require("../models/task");

const router = express.Router();

const JWT_SECRET = process.env.JWT_SECRET || "daily-planner-secret-key";

// ========================================
// Authentication middleware
// ========================================
function authenticateToken(req, res, next) {
  const authHeader = req.headers.authorization;

  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({
      message: "Authentication required"
    });
  }

  const token = authHeader.split(" ")[1];

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    req.user = decoded;

    next();
  } catch (error) {
    return res.status(401).json({
      message: "Invalid or expired token"
    });
  }
}

// ========================================
// Get only the logged-in user's tasks
// ========================================
router.get("/", authenticateToken, async (req, res) => {
  try {
    const tasks = await Task.find({
      user: req.user.userId
    }).sort({
      date: 1,
      createdAt: 1
    });

    res.json(tasks);
  } catch (error) {
    console.error("Fetch tasks error:", error);

    res.status(500).json({
      message: "Failed to fetch tasks"
    });
  }
});

// ========================================
// Create a task for the logged-in user
// ========================================
router.post("/", authenticateToken, async (req, res) => {
  try {
    const task = await Task.create({
      ...req.body,
      user: req.user.userId
    });

    res.status(201).json(task);
  } catch (error) {
    console.error("Create task error:", error);

    res.status(400).json({
      message: "Failed to create task"
    });
  }
});

// ========================================
// Update only the logged-in user's task
// ========================================
router.put("/:id", authenticateToken, async (req, res) => {
  try {
    const task = await Task.findOneAndUpdate(
      {
        _id: req.params.id,
        user: req.user.userId
      },
      req.body,
      {
        new: true
      }
    );

    if (!task) {
      return res.status(404).json({
        message: "Task not found"
      });
    }

    res.json(task);
  } catch (error) {
    console.error("Update task error:", error);

    res.status(400).json({
      message: "Failed to update task"
    });
  }
});

// ========================================
// Delete only the logged-in user's task
// ========================================
router.delete("/:id", authenticateToken, async (req, res) => {
  try {
    const task = await Task.findOneAndDelete({
      _id: req.params.id,
      user: req.user.userId
    });

    if (!task) {
      return res.status(404).json({
        message: "Task not found"
      });
    }

    res.json({
      message: "Task deleted successfully"
    });
  } catch (error) {
    console.error("Delete task error:", error);

    res.status(400).json({
      message: "Failed to delete task"
    });
  }
});

module.exports = router;