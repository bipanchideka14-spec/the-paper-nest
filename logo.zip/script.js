// ==========================================
// DAILY PLANNER
// ==========================================

// ---------- AUTHENTICATION ----------

const token = localStorage.getItem("token");
const loggedInUser = JSON.parse(localStorage.getItem("user") || "null");

// Display logged-in user's name
const loggedInUserElement = document.getElementById("loggedInUser");

if (loggedInUserElement && loggedInUser) {
    loggedInUserElement.textContent = loggedInUser.name;
}

// If user is not logged in, go to login page
if (!token) {
    window.location.href = "login.html";
}

// ---------- DATA ----------

let selectedDate = new Date();
let tasks = [];
let editingTaskId = null;


// ---------- ELEMENTS ----------

const currentDate = document.getElementById("currentDate");
const dayName = document.getElementById("dayName");
const topDate = document.getElementById("topDate");
const todayLabel = document.getElementById("todayLabel");

const prevDay = document.getElementById("prevDay");
const nextDay = document.getElementById("nextDay");
const todayBtn = document.getElementById("todayBtn");

const taskList = document.getElementById("taskList");
const emptyState = document.getElementById("emptyState");

const totalTasks = document.getElementById("totalTasks");
const completedTasks = document.getElementById("completedTasks");
const pendingTasks = document.getElementById("pendingTasks");
const progressPercentage = document.getElementById("progressPercentage");

const progress = document.getElementById("progress");
const progressNumber = document.getElementById("progressNumber");
const progressText = document.getElementById("progressText");

const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const priorityFilter = document.getElementById("priorityFilter");

const taskModal = document.getElementById("taskModal");
const openModal = document.getElementById("openModal");
const emptyAddBtn = document.getElementById("emptyAddBtn");
const closeModal = document.getElementById("closeModal");
const cancelTask = document.getElementById("cancelTask");

const taskForm = document.getElementById("taskForm");

const modalTitle = document.getElementById("modalTitle");

const taskTitle = document.getElementById("taskTitle");
const taskDescription = document.getElementById("taskDescription");
const taskPriority = document.getElementById("taskPriority");
const taskCategory = document.getElementById("taskCategory");
const taskTime = document.getElementById("taskTime");

const themeBtn = document.getElementById("themeBtn");
const themeIcon = document.getElementById("themeIcon");


// ---------- LOAD TASKS FROM MONGODB ----------

async function loadTasks() {

    try {

        const response = await fetch("/api/tasks", {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        if (!response.ok) {

            if (response.status === 401) {
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                window.location.href = "login.html";
                return;
            }

            throw new Error("Failed to load tasks");
        }

        tasks = await response.json();

        // MongoDB uses _id.
        // We also keep id for the existing frontend functions.
        tasks.forEach(function (task) {
            task.id = task._id;
        });

        renderTasks();

    } catch (error) {

        console.error("Error loading tasks:", error);

    }
}


// ---------- DATE ----------

function getDateKey(date) {

    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");

    return `${year}-${month}-${day}`;
}


function displayDate() {

    currentDate.textContent =
        selectedDate.toLocaleDateString("en-US", {
            month: "long",
            day: "numeric",
            year: "numeric"
        });


    dayName.textContent =
        selectedDate.toLocaleDateString("en-US", {
            weekday: "long"
        });


    topDate.textContent =
        selectedDate.toLocaleDateString("en-US", {
            month: "short",
            day: "numeric",
            year: "numeric"
        });


    const today = new Date();

    const isToday =
        getDateKey(selectedDate) === getDateKey(today);


    todayLabel.style.display =
        isToday ? "inline-block" : "none";


    renderTasks();
}


// ---------- DATE NAVIGATION ----------

prevDay.addEventListener("click", function () {

    selectedDate.setDate(
        selectedDate.getDate() - 1
    );

    displayDate();

});


nextDay.addEventListener("click", function () {

    selectedDate.setDate(
        selectedDate.getDate() + 1
    );

    displayDate();

});


todayBtn.addEventListener("click", function () {

    selectedDate = new Date();

    displayDate();

});


// ---------- MODAL ----------

function showModal(editTask = null) {

    taskModal.classList.add("show");


    if (editTask) {

        editingTaskId = editTask.id;

        modalTitle.textContent = "Edit Task";

        taskTitle.value = editTask.title;

        taskDescription.value =
            editTask.description || "";

        taskPriority.value =
            editTask.priority || "Medium";

        taskCategory.value =
            editTask.category || "Other";

        taskTime.value =
            editTask.time || "";

    } else {

        editingTaskId = null;

        modalTitle.textContent = "Add New Task";

        taskForm.reset();

        taskPriority.value = "Medium";

    }


    taskTitle.focus();
}


function hideModal() {

    taskModal.classList.remove("show");

    editingTaskId = null;

    taskForm.reset();
}


// ---------- OPEN / CLOSE MODAL ----------

openModal.addEventListener("click", function () {

    showModal();

});


emptyAddBtn.addEventListener("click", function () {

    showModal();

});


closeModal.addEventListener("click", hideModal);

cancelTask.addEventListener("click", hideModal);


// Close modal when clicking outside the modal box

taskModal.addEventListener("click", function (event) {

    if (event.target === taskModal) {
        hideModal();
    }

});


// ---------- ADD / EDIT TASK ----------

taskForm.addEventListener("submit", async function (event) {

    event.preventDefault();


    const title = taskTitle.value.trim();


    if (title === "") {
        return;
    }


    const taskData = {

        title: title,

        description:
            taskDescription.value.trim(),

        priority:
            taskPriority.value,

        category:
            taskCategory.value,

        time:
            taskTime.value,

        date:
            getDateKey(selectedDate),

        completed:
            false
    };


    try {

        // ---------- EDIT EXISTING TASK ----------

        if (editingTaskId !== null) {

            const response = await fetch(
                `/api/tasks/${editingTaskId}`,
                {
                    method: "PUT",

                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    },

                    body: JSON.stringify({
                        title: taskData.title,
                        description: taskData.description,
                        priority: taskData.priority,
                        category: taskData.category,
                        time: taskData.time
                    })
                }
            );


            if (!response.ok) {

                if (response.status === 401) {
                    localStorage.removeItem("token");
                    localStorage.removeItem("user");
                    window.location.href = "login.html";
                    return;
                }

                throw new Error("Failed to update task");
            }


            const updatedTask =
                await response.json();


            updatedTask.id =
                updatedTask._id;


            const index =
                tasks.findIndex(function (task) {

                    return task.id === editingTaskId;

                });


            if (index !== -1) {

                tasks[index] =
                    updatedTask;

            }

        }


        // ---------- ADD NEW TASK ----------

        else {

            const response = await fetch(
                "/api/tasks",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    },

                    body: JSON.stringify(taskData)
                }
            );


            if (!response.ok) {

                if (response.status === 401) {
                    localStorage.removeItem("token");
                    localStorage.removeItem("user");
                    window.location.href = "login.html";
                    return;
                }

                throw new Error("Failed to create task");
            }


            const newTask =
                await response.json();


            newTask.id =
                newTask._id;


            tasks.push(newTask);

        }


        hideModal();

        renderTasks();


    } catch (error) {

        console.error(
            "Error saving task:",
            error
        );

        alert(
            "Could not save task. Please try again."
        );

    }

});


// ---------- GET CURRENT DATE'S TASKS ----------

function getCurrentTasks() {

    return tasks.filter(function (task) {

        return task.date ===
            getDateKey(selectedDate);

    });

}


// ---------- RENDER TASKS ----------

function renderTasks() {

    taskList.innerHTML = "";


    let currentTasks =
        getCurrentTasks();


    // ---------- SEARCH ----------

    const search =
        searchInput.value
            .toLowerCase()
            .trim();


    if (search !== "") {

        currentTasks =
            currentTasks.filter(function (task) {

                return (
                    task.title
                        .toLowerCase()
                        .includes(search)
                    ||
                    (task.description || "")
                        .toLowerCase()
                        .includes(search)
                );

            });

    }


    // ---------- CATEGORY FILTER ----------

    if (categoryFilter.value !== "All") {

        currentTasks =
            currentTasks.filter(function (task) {

                return (
                    task.category ===
                    categoryFilter.value
                );

            });

    }


    // ---------- PRIORITY FILTER ----------

    if (priorityFilter.value !== "All") {

        currentTasks =
            currentTasks.filter(function (task) {

                return (
                    task.priority ===
                    priorityFilter.value
                );

            });

    }


    // ---------- EMPTY STATE ----------

    if (currentTasks.length === 0) {

        emptyState.style.display =
            "block";

    } else {

        emptyState.style.display =
            "none";

    }


    // ---------- CREATE TASK CARDS ----------

    currentTasks.forEach(function (task) {

        const taskElement =
            document.createElement("div");


        taskElement.className =
            "task";


        if (task.completed) {

            taskElement.classList.add(
                "completed"
            );

        }


        let timeText = "";


        if (task.time) {

            timeText = `
                <span class="task-time">
                    🕐 ${formatTime(task.time)}
                </span>
            `;

        }


        taskElement.innerHTML = `

            <div class="task-left">

                <input
                    type="checkbox"
                    class="task-checkbox"
                    ${task.completed ? "checked" : ""}
                    onchange="toggleTask('${task.id}')"
                >

                <div class="task-info">

                    <div class="task-title">
                        ${escapeHTML(task.title)}
                    </div>

                    ${
                        task.description
                        ?
                        `<div class="task-description">
                            ${escapeHTML(task.description)}
                        </div>`
                        :
                        ""
                    }

                    <div class="task-meta">

                        <span class="badge category-badge">
                            ${getCategoryIcon(task.category)}
                            ${task.category}
                        </span>

                        <span class="badge ${getPriorityClass(task.priority)}">
                            ${getPriorityIcon(task.priority)}
                            ${task.priority}
                        </span>

                        ${timeText}

                    </div>

                </div>

            </div>


            <div class="task-actions">

                <button
                    class="task-action"
                    title="Edit"
                    onclick="editTask('${task.id}')"
                >
                    ✏️
                </button>

                <button
                    class="task-action"
                    title="Delete"
                    onclick="deleteTask('${task.id}')"
                >
                    🗑️
                </button>

            </div>

        `;


        taskList.appendChild(
            taskElement
        );

    });


    updateStatistics();

}


// ---------- COMPLETE TASK ----------

async function toggleTask(id) {

    const task =
        tasks.find(function (task) {

            return task.id === id;

        });


    if (!task) {
        return;
    }


    const newCompleted =
        !task.completed;


    try {

        const response =
            await fetch(
                `/api/tasks/${id}`,
                {
                    method: "PUT",

                    headers: {
                        "Content-Type": "application/json",
                        "Authorization": `Bearer ${token}`
                    },

                    body: JSON.stringify({
                        completed:
                            newCompleted
                    })
                }
            );


        if (!response.ok) {

            if (response.status === 401) {
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                window.location.href = "login.html";
                return;
            }

            throw new Error(
                "Failed to update task"
            );

        }


        task.completed =
            newCompleted;


        renderTasks();


    } catch (error) {

        console.error(
            "Error updating task:",
            error
        );

        alert(
            "Could not update task."
        );

    }

}


// ---------- DELETE TASK ----------

async function deleteTask(id) {

    const confirmed =
        confirm("Delete this task?");


    if (!confirmed) {
        return;
    }


    try {

        const response =
            await fetch(
                `/api/tasks/${id}`,
                {
                    method: "DELETE",

                    headers: {
                        "Authorization": `Bearer ${token}`
                    }
                }
            );


        if (!response.ok) {

            if (response.status === 401) {
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                window.location.href = "login.html";
                return;
            }

            throw new Error(
                "Failed to delete task"
            );

        }


        tasks =
            tasks.filter(function (task) {

                return task.id !== id;

            });


        renderTasks();


    } catch (error) {

        console.error(
            "Error deleting task:",
            error
        );

        alert(
            "Could not delete task."
        );

    }

}


// ---------- EDIT TASK ----------

function editTask(id) {

    const task =
        tasks.find(function (task) {

            return task.id === id;

        });


    if (!task) {
        return;
    }


    showModal(task);

}


// ---------- STATISTICS ----------

function updateStatistics() {

    const currentTasks =
        getCurrentTasks();


    const total =
        currentTasks.length;


    const completed =
        currentTasks.filter(function (task) {

            return task.completed;

        }).length;


    const pending =
        total - completed;


    let percentage = 0;


    if (total > 0) {

        percentage =
            Math.round(
                (completed / total) * 100
            );

    }


    totalTasks.textContent =
        total;


    completedTasks.textContent =
        completed;


    pendingTasks.textContent =
        pending;


    progressPercentage.textContent =
        percentage + "%";


    progressNumber.textContent =
        percentage + "%";


    progress.style.width =
        percentage + "%";


    if (total === 0) {

        progressText.textContent =
            "Let's get things done!";

    }

    else if (percentage === 100) {

        progressText.textContent =
            "Amazing! All tasks completed 🎉";

    }

    else if (percentage >= 70) {

        progressText.textContent =
            "You're doing great! Keep going 💪";

    }

    else if (percentage >= 40) {

        progressText.textContent =
            "Good progress! Keep it up.";

    }

    else {

        progressText.textContent =
            "Let's get things done!";

    }

}


// ---------- SEARCH / FILTER ----------

searchInput.addEventListener(
    "input",
    renderTasks
);


categoryFilter.addEventListener(
    "change",
    renderTasks
);


priorityFilter.addEventListener(
    "change",
    renderTasks
);


// ---------- CATEGORY ICON ----------

function getCategoryIcon(category) {

    const icons = {

        Study: "📚",

        Work: "💼",

        Personal: "🏠",

        Health: "💪",

        Other: "📌"

    };


    return icons[category] || "📌";

}


// ---------- PRIORITY ICON ----------

function getPriorityIcon(priority) {

    const icons = {

        High: "🔴",

        Medium: "🟡",

        Low: "🟢"

    };


    return icons[priority] || "";

}


// ---------- PRIORITY CSS ----------

function getPriorityClass(priority) {

    if (priority === "High") {

        return "priority-high";

    }


    if (priority === "Medium") {

        return "priority-medium";

    }


    return "priority-low";

}


// ---------- TIME ----------

function formatTime(time) {

    const [hour, minute] =
        time.split(":");


    let h =
        parseInt(hour);


    const ampm =
        h >= 12 ? "PM" : "AM";


    h =
        h % 12 || 12;


    return `${h}:${minute} ${ampm}`;

}


// ---------- SECURITY ----------

function escapeHTML(text) {

    const div =
        document.createElement("div");


    div.textContent =
        text || "";


    return div.innerHTML;

}


// ---------- DARK MODE ----------

themeBtn.addEventListener(
    "click",
    function () {

        document.body.classList.toggle(
            "dark"
        );


        const dark =
            document.body.classList.contains(
                "dark"
            );


        themeIcon.textContent =
            dark ? "☀️" : "🌙";


        localStorage.setItem(
            "planifyTheme",
            dark ? "dark" : "light"
        );

    }
);


// ---------- LOAD SAVED THEME ----------

const savedTheme =
    localStorage.getItem(
        "planifyTheme"
    );


if (savedTheme === "dark") {

    document.body.classList.add(
        "dark"
    );

    themeIcon.textContent =
        "☀️";

}

// ---------- LOGOUT ----------

const logoutBtn = document.getElementById("logoutBtn");

if (logoutBtn) {
    logoutBtn.addEventListener("click", function () {

        localStorage.removeItem("token");
        localStorage.removeItem("user");

        window.location.href = "login.html";
    });
}


// ---------- START ----------

displayDate();

loadTasks();